import { Component, OnInit } from '@angular/core';
import { InventoryService, InventoryItem, Category, StockStatus, PopularItem } from '../inventory.service';

@Component({
  selector: 'app-inventory-form',
  templateUrl: './inventory-form.component.html',
  styleUrls: ['./inventory-form.component.css']
})
export class InventoryFormComponent implements OnInit {
  formData = {
    itemName: '',
    category: 'Electronics' as Category,
    quantity: 0,
    price: 0,
    supplierName: '',
    stockStatus: 'In Stock' as StockStatus,
    popularItem: 'No' as PopularItem,
    comment: ''
  };
  
  deleteItemName: string = '';
  message: string = '';
  messageType: string = '';
  isEditMode: boolean = false;
  editOriginalName: string = '';

  categories: Category[] = ['Electronics', 'Furniture', 'Clothing', 'Tools', 'Miscellaneous'];
  stockStatuses: StockStatus[] = ['In Stock', 'Low Stock', 'Out of Stock'];
  popularOptions: PopularItem[] = ['Yes', 'No'];

  constructor(private inventoryService: InventoryService) {}

  ngOnInit(): void {
    const editData = localStorage.getItem('editItem');
    if (editData) {
      const item: InventoryItem = JSON.parse(editData);
      this.formData = {
        itemName: item.itemName,
        category: item.category,
        quantity: item.quantity,
        price: item.price,
        supplierName: item.supplierName,
        stockStatus: item.stockStatus,
        popularItem: item.popularItem,
        comment: item.comment || ''
      };
      this.isEditMode = true;
      this.editOriginalName = item.itemName;
      localStorage.removeItem('editItem');
      this.showMessage(`✏️ Editing "${item.itemName}" - click Update to save`, 'info');
    }
  }

  showMessage(msg: string, type: string): void {
    this.message = msg;
    this.messageType = type;
    setTimeout(() => { this.message = ''; }, 3000);
  }

  addItem(): void {
    if (!this.validateForm()) return;
    const result = this.inventoryService.addItem(this.formData);
    if (result.success) {
      this.showMessage(result.message, 'success');
      this.resetForm();
    } else {
      this.showMessage(result.message, 'error');
    }
  }

  updateItem(): void {
    if (!this.validateForm()) return;
    const targetName = this.isEditMode ? this.editOriginalName : this.formData.itemName;
    const result = this.inventoryService.updateItem(targetName, this.formData);
    if (result.success) {
      this.showMessage(result.message, 'success');
      this.resetForm();
      this.isEditMode = false;
      this.editOriginalName = '';
    } else {
      this.showMessage(result.message, 'error');
    }
  }

  deleteItem(): void {
    if (!this.deleteItemName.trim()) {
      this.showMessage('❌ Please enter the Item Name to delete!', 'error');
      return;
    }
    if (confirm(`⚠️ Are you sure you want to delete "${this.deleteItemName}"?`)) {
      const result = this.inventoryService.deleteItem(this.deleteItemName);
      if (result.success) {
        this.showMessage(result.message, 'success');
        this.deleteItemName = '';
      } else {
        this.showMessage(result.message, 'error');
      }
    }
  }

  validateForm(): boolean {
    if (!this.formData.itemName.trim()) { this.showMessage('❌ Item Name is required!', 'error'); return false; }
    if (!this.formData.supplierName.trim()) { this.showMessage('❌ Supplier Name is required!', 'error'); return false; }
    if (this.formData.quantity < 0) { this.showMessage('❌ Quantity must be 0 or greater!', 'error'); return false; }
    if (this.formData.price < 0) { this.showMessage('❌ Price must be 0 or greater!', 'error'); return false; }
    return true;
  }

  resetForm(): void {
    this.formData = {
      itemName: '', category: 'Electronics', quantity: 0, price: 0,
      supplierName: '', stockStatus: 'In Stock', popularItem: 'No', comment: ''
    };
    this.isEditMode = false;
    this.editOriginalName = '';
  }
}