import { Component } from '@angular/core';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent {
  activeIndex: number = -1;
  toggleFAQ(index: number): void { this.activeIndex = this.activeIndex === index ? -1 : index; }
}