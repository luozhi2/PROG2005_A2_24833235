import { Component, OnInit } from '@angular/core';
import { InventoryService, InventoryItem } from '../inventory.service';

@Component({
  selector: 'app-popular-items',
  templateUrl: './popular-items.component.html',
  styleUrls: ['./popular-items.component.css']
})
export class PopularItemsComponent implements OnInit {
  popularItems: InventoryItem[] = [];

  constructor(private inventoryService: InventoryService) {}

  ngOnInit(): void {
    this.inventoryService.getInventory().subscribe(() => {
      this.popularItems = this.inventoryService.getPopularItems();
    });
  }

  getStockIcon(status: string): string {
    switch(status) {
      case 'In Stock': return '🟢';
      case 'Low Stock': return '🟡';
      case 'Out of Stock': return '⚫';
      default: return '';
    }
  }

  getStockClass(status: string): string {
    switch(status) {
      case 'In Stock': return 'stock-InStock';
      case 'Low Stock': return 'stock-LowStock';
      case 'Out of Stock': return 'stock-OutOfStock';
      default: return '';
    }
  }

  editItem(item: InventoryItem): void {
    localStorage.setItem('editItem', JSON.stringify(item));
    window.location.href = '/form';
  }
}