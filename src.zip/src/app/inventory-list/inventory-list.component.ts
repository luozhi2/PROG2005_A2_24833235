import { Component, OnInit } from '@angular/core';
import { InventoryService, InventoryItem } from '../inventory.service';

@Component({
  selector: 'app-inventory-list',
  templateUrl: './inventory-list.component.html',
  styleUrls: ['./inventory-list.component.css']
})
export class InventoryListComponent implements OnInit {
  items: InventoryItem[] = [];
  searchTerm: string = '';
  private allItems: InventoryItem[] = [];

  constructor(private inventoryService: InventoryService) {}

  ngOnInit(): void {
    this.inventoryService.getInventory().subscribe(items => {
      this.allItems = items;
      this.items = [...items];
    });
  }

  search(): void {
    if (!this.searchTerm.trim()) {
      this.items = [...this.allItems];
      return;
    }
    this.items = this.inventoryService.searchItems(this.searchTerm);
  }

  resetSearch(): void {
    this.searchTerm = '';
    this.items = [...this.allItems];
  }

  editItem(item: InventoryItem): void {
    localStorage.setItem('editItem', JSON.stringify(item));
    window.location.href = '/form';
  }

  getStockIcon(status: string): string {
    switch(status) {
      case 'In Stock': return '🟢';
      case 'Low Stock': return '🟡';
      case 'Out of Stock': return '⚫';
      default: return '';
    }
  }

  getStockClass(status: string): string {
    switch(status) {
      case 'In Stock': return 'stock-InStock';
      case 'Low Stock': return 'stock-LowStock';
      case 'Out of Stock': return 'stock-OutOfStock';
      default: return '';
    }
  }
}