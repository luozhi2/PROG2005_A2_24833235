import { Component, OnInit, OnDestroy } from '@angular/core';
import { InventoryService, ActivityLog } from '../inventory.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  stats = { total: 0, inStock: 0, lowStock: 0, outStock: 0, popular: 0 };
  activityLogs: ActivityLog[] = [];
  private subscriptions: Subscription[] = [];

  constructor(private inventoryService: InventoryService) {}

  ngOnInit(): void {
    this.subscriptions.push(
      this.inventoryService.getInventory().subscribe(() => {
        this.stats = this.inventoryService.getStats();
      }),
      this.inventoryService.getActivityLogs().subscribe(logs => {
        this.activityLogs = logs.slice(0, 10);
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
}